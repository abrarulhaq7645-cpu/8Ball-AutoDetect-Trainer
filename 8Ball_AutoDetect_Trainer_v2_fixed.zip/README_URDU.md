# 8 Ball Auto Detect Trainer

یہ Android Studio project لائیو اسکرین کو MediaProjection کے ذریعے پڑھ کر table/balls کی
heuristic detection اور training overlay دکھاتا ہے۔

Features:
- Auto table boundary
- Six pocket markers
- Cue/object ball heuristic detection
- Aim line
- Nearest-pocket guide
- Live overlay

اہم:
یہ learning/training assistant ہے۔ Auto-click یا auto-play شامل نہیں ہے۔
Detector heuristic ہے؛ مختلف resolutions/themes پر calibration کی ضرورت ہو سکتی ہے۔

Build:
1. Android Studio میں project کھولیں۔
2. Gradle sync کریں۔
3. Android 8+ device پر Run/Build APK کریں۔
4. App میں "Allow overlay" اور "Start Live Auto Detect" دبائیں۔
5. Screen capture permission دیں۔
6. 8 Ball Pool کھولیں؛ overlay analysis دکھائے گا۔

نوٹ: مکمل billiards physics (exact cushion collision, spin, power) کے لیے مزید calibration/physics
engine درکار ہے؛ یہ version بنیادی live detector + guide فراہم کرتا ہے۔
