package com.abrar.eightballtrainer

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView
import kotlin.math.*

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var wm: WindowManager
    private var overlay: TrainerOverlay? = null
    private val detector = BallDetector()

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val width = dm.widthPixels
        val height = dm.heightPixels
        val density = dm.densityDpi

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "8BallAutoDetect",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )
        overlay = TrainerOverlay(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(overlay, lp)

        reader!!.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val bmp = imageToBitmap(image)
                val balls = detector.detect(bmp)
                overlay?.post { overlay?.setBalls(balls) }
                bmp.recycle()
            } catch (_: Throwable) {
            } finally {
                image.close()
            }
        }, Handler(Looper.getMainLooper()))
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val p = image.planes[0]
        val w = image.width
        val h = image.height
        val pixelStride = p.pixelStride
        val rowStride = p.rowStride
        val rowPadding = rowStride - pixelStride * w
        val bmp = Bitmap.createBitmap(
            w + rowPadding / pixelStride, h, Bitmap.Config.ARGB_8888
        )
        bmp.copyPixelsFromBuffer(p.buffer)
        return Bitmap.createBitmap(bmp, 0, 0, w, h)
    }

    override fun onDestroy() {
        overlay?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        display?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("trainer", "8 Ball Trainer", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun notification(): Notification {
        return Notification.Builder(this, "trainer")
            .setContentTitle("8 Ball Auto Detect Trainer")
            .setContentText("Live table analysis is running")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
    }
}

class TrainerOverlay(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var balls: List<Ball> = emptyList()

    fun setBalls(b: List<Ball>) {
        balls = b
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = height.toFloat()

        // Reference table bounds for the supplied 1536x691 screenshots.
        val l = w * 300f / 1536f
        val r = w * 1250f / 1536f
        val t = h * 150f / 691f
        val b = h * 625f / 691f

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = Color.argb(150, 0, 255, 120)
        c.drawRect(l, t, r, b, paint)

        // Six pockets.
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(170, 0, 0, 0)
        val pockets = arrayOf(
            PointF(l, t), PointF((l+r)/2f, t), PointF(r, t),
            PointF(l, b), PointF((l+r)/2f, b), PointF(r, b)
        )
        for (p in pockets) c.drawCircle(p.x, p.y, min(w,h)*0.022f, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        for (ball in balls) {
            paint.color = Color.argb(210, 255, 235, 50)
            c.drawCircle(ball.x, ball.y, max(ball.radius, 7f), paint)
        }

        val cue = balls.firstOrNull { it.type == "cue/white" }
        val target = balls.firstOrNull { it.type != "cue/white" && it.type != "8 / dark" }
        if (cue != null && target != null) {
            paint.color = Color.argb(220, 0, 255, 80)
            paint.strokeWidth = 5f
            c.drawLine(cue.x, cue.y, target.x, target.y, paint)

            val p = nearestPocket(target, pockets)
            paint.color = Color.argb(210, 255, 210, 40)
            c.drawLine(target.x, target.y, p.x, p.y, paint)
        }

        paint.style = Paint.Style.FILL
        paint.textSize = 28f
        paint.color = Color.WHITE
        c.drawText("AUTO-DETECT: ${balls.size} balls", 24f, 42f, paint)
        c.drawText("Training guide • no auto-play", 24f, 76f, paint)
    }

    private fun nearestPocket(ball: Ball, pockets: Array<PointF>): PointF =
        pockets.minBy { hypot(it.x - ball.x, it.y - ball.y) }
}
