package com.abrar.eightballtrainer

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.*

data class Ball(val x: Float, val y: Float, val radius: Float, val type: String)

class BallDetector {

    // Coordinates are normalized to the reference 1536x691 layout.
    // This makes the detector usable on different screen sizes.
    private val left = 300f / 1536f
    private val right = 1250f / 1536f
    private val top = 150f / 691f
    private val bottom = 625f / 691f

    fun detect(src: Bitmap): List<Ball> {
        val w = src.width
        val h = src.height
        val x0 = (left * w).toInt().coerceAtLeast(0)
        val x1 = (right * w).toInt().coerceAtMost(w - 1)
        val y0 = (top * h).toInt().coerceAtLeast(0)
        val y1 = (bottom * h).toInt().coerceAtMost(h - 1)

        val sx = max(1, w / 768)
        val sy = max(1, h / 346)
        val maskW = ((x1 - x0) / sx).coerceAtLeast(1)
        val maskH = ((y1 - y0) / sy).coerceAtLeast(1)
        val mask = BooleanArray(maskW * maskH)

        for (my in 0 until maskH) {
            val py = y0 + my * sy
            for (mx in 0 until maskW) {
                val px = x0 + mx * sx
                val c = src.getPixel(px, py)
                val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
                val maxc = max(r, max(g, b))
                val minc = min(r, min(g, b))
                val sat = maxc - minc
                val bright = maxc
                // Balls are either colorful, very light (cue/white), or very dark (8).
                mask[my * maskW + mx] =
                    (sat > 45 && bright > 70) ||
                    (bright > 205 && sat < 45) ||
                    (bright < 65 && sat < 45)
            }
        }

        val seen = BooleanArray(mask.size)
        val out = ArrayList<Ball>()
        val qx = IntArray(mask.size)
        val qy = IntArray(mask.size)

        for (sy0 in 0 until maskH) for (sx0 in 0 until maskW) {
            val start = sy0 * maskW + sx0
            if (!mask[start] || seen[start]) continue
            var head = 0; var tail = 0
            qx[tail] = sx0; qy[tail++] = sy0; seen[start] = true
            var count = 0; var sumX = 0.0; var sumY = 0.0
            var minX = sx0; var maxX = sx0; var minY = sy0; var maxY = sy0

            while (head < tail) {
                val cx = qx[head]; val cy = qy[head++]
                count++; sumX += cx; sumY += cy
                minX = min(minX, cx); maxX = max(maxX, cx)
                minY = min(minY, cy); maxY = max(maxY, cy)
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = cx + dx; val ny = cy + dy
                    if (nx !in 0 until maskW || ny !in 0 until maskH) continue
                    val ni = ny * maskW + nx
                    if (mask[ni] && !seen[ni]) {
                        seen[ni] = true
                        qx[tail] = nx; qy[tail++] = ny
                    }
                }
            }

            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            // A 2-4% screen-height ball is expected in this layout.
            if (count in 8..220 && bw in 4..32 && bh in 4..32) {
                val aspect = bw.toFloat() / bh.toFloat()
                if (aspect in 0.55f..1.8f) {
                    val px = x0 + (sumX / count * sx)
                    val py = y0 + (sumY / count * sy)
                    val rad = max(bw, bh) * sx / 2f
                    val type = classify(src, px.toInt(), py.toInt())
                    out.add(Ball(px, py, rad, type))
                }
            }
        }
        return mergeNearby(out, w, h)
    }

    private fun classify(b: Bitmap, x: Int, y: Int): String {
        val rr = 8
        var sr = 0L; var sg = 0L; var sb = 0L; var n = 0
        for (dy in -rr..rr step 2) for (dx in -rr..rr step 2) {
            val px = (x + dx).coerceIn(0, b.width - 1)
            val py = (y + dy).coerceIn(0, b.height - 1)
            val c = b.getPixel(px, py)
            sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c); n++
        }
        val r = sr / n; val g = sg / n; val bl = sb / n
        val maxc = max(r, max(g, bl)); val minc = min(r, min(g, bl))
        if (maxc < 70) return "8 / dark"
        if (maxc > 205 && maxc - minc < 45) return "cue/white"
        if (g > r * 1.18 && g > bl * 1.12) return "green"
        if (r > g * 1.25 && r > bl * 1.25) return "red/orange"
        if (bl > r * 1.18 && bl > g * 1.08) return "blue/purple"
        return "object"
    }

    private fun mergeNearby(list: List<Ball>, w: Int, h: Int): List<Ball> {
        val result = ArrayList<Ball>()
        val minDist = min(w, h) * 0.018f
        for (b in list) {
            val existing = result.indexOfFirst {
                hypot(it.x - b.x, it.y - b.y) < minDist
            }
            if (existing < 0) result.add(b)
        }
        return result
    }
}
